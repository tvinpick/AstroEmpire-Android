AstroEmpire Android
===================

Это офлайн-обёртка текущей HTML/JavaScript-версии AstroEmpire.
Игра находится в app/src/main/assets/index.html и запускается во встроенном Android WebView.

Сборка APK в Android Studio:
1. Откройте папку AstroEmpire_Android как проект.
2. Дождитесь установки Android SDK 35 и синхронизации Gradle.
3. Build > Build APK(s).
4. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Особенности:
- полностью офлайн;
- JavaScript + DOM Storage включены;
- localStorage имеет стабильный origin https://astroempire.local/;
- полноэкранный immersive-режим;
- альбомная ориентация;
- экран не гаснет во время игры;
- кнопка Android «Назад» сначала пытается закрыть открытое игровое окно.

Пакет: com.astroempire.game
minSdk: 24
compileSdk/targetSdk: 35
